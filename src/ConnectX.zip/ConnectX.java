/*
* ConnectX - CMP 326
* Author: Jeffrey Mathew
* Objective: To connect x amount of dots horizontally, vertically or diagonally before your opponent does.
 */



import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ConnectX extends JFrame{

    private static ConnectX game = new ConnectX();
    private static JPanel jMain, jBoard, jIO, jButton;
    private static JLabel jDisplay;
    private static JPanel[][] board;
    private static String playerOne, playerTwo, numOfRowsEntry, currPlayer;
    private static int numofRows, p1count, p2count;
    private static JButton[] label;
    private static Color backgroundColor, borderColor;
    private static ImageIcon greenIMG, yellowIMG;


    static{
       playerOne = JOptionPane.showInputDialog(game, "Enter the name of the First Player", "First Player", JOptionPane.PLAIN_MESSAGE);
       playerTwo = JOptionPane.showInputDialog(game, "Enter the name of the Second Player", "Second Player", JOptionPane.PLAIN_MESSAGE);
      // numOfRowsEntry = JOptionPane.showInputDialog(game, "Enter the number of Rows", "Number of Rows", JOptionPane.PLAIN_MESSAGE);
       //numofRows = Integer.parseInt(numOfRowsEntry);

    }

    private static void CreateGUI(){
        jMain = new JPanel();
        jBoard = new JPanel();
        jButton = new JPanel();
        jIO = new JPanel();
        jDisplay = new JLabel();

        //jMain Settings & Configurations
        jMain.setLayout(new BorderLayout());

        //jIO Settings
        jIO.setLayout(new BorderLayout());
        backgroundColor = new Color(30, 53, 173);
        jIO.setBackground(backgroundColor);
        jIO.add(jDisplay,BorderLayout.NORTH);
        jIO.add(jButton, BorderLayout.SOUTH);


        //jDisplay Settings
        jDisplay.setHorizontalAlignment(JLabel.CENTER);
        game.updateText("Hey there, "+ playerOne +" goes first!");
        currPlayer = playerOne;
        p1count = 0;
        p2count = 0;

        //jButtons Setting
        jButton.setLayout(new GridLayout(1,7));
        game.displayLabelButton();

        //jBoard Settings
        jBoard = new JPanel();
        jBoard.setLayout(new GridLayout(6,7));
        game.displayBoard();

        //Global Settings
        jMain.add(jIO, BorderLayout.NORTH);
        jMain.add(jBoard, BorderLayout.CENTER);
        game.add(jMain);
        game.setTitle("Connect4 - Players (" + playerOne + " - "+p1count+" Wins, " + playerTwo + " - "+p2count+" Wins)");
        game.setDefaultCloseOperation(EXIT_ON_CLOSE);
        game.setSize(900, 600);
        game.setVisible(true);

    }

    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater( new Runnable(){
            public void run() {
                CreateGUI();
            }
        });
    }
    public void updateText(String msg){
        jDisplay.setText("<HTML><H1 color=white>"+msg+"</H1></HTML>");
    }



    public void displayLabelButton(){
        label = new JButton[7];
        for(int i=0; i < label.length; i++){
            label[i]=new JButton();
            label[i].setBackground(Color.BLUE);
            label[i].setFocusable(false);
            label[i].setBorder(BorderFactory.createLineBorder(Color.WHITE, 2));
            label[i].setFont(new Font(Font.SANS_SERIF,Font.ITALIC,30));

            label[i].setForeground(Color.WHITE);
            label[i].addActionListener(this::actionPerformed);
            label[i].setEnabled(true);
            label[i].setText("<html><h4 color=white> Drop Here</h4></html>");
            jButton.add(label[i]);

        }
    }


    public void displayBoard() {
        board = new JPanel[6][7];
        for(int row=0; row<board.length; row++){
            for(int col=0; col<board[row].length; col++){
                board[row][col] = new JPanel();
                board[row][col].setBackground(Color.BLUE);
                board[row][col].setFocusable(false);
                board[row][col].setBorder(BorderFactory.createLineBorder(Color.WHITE, 2));
                jBoard.add(board[row][col]);
            }
        }
    }
    public void actionPerformed(ActionEvent e) {
        JButton btnClicked = (JButton) e.getSource();

        for (int j = 0; j < label.length; j++) {
            if (btnClicked.equals(label[j])) {
                nextDrop(j);

            }
        }
        if(game.isWinner(currPlayer) || game.isFull()){
            game.displayWinner();
            game.playAnotherGame();
        }

        game.updateCurrPlayer();
        game.updateText(currPlayer + "'s Turn");
    }

    public void playAnotherGame(){
        int yesNo = JOptionPane.showConfirmDialog(null, "Do you want to play another game?");
        if(yesNo == 0){
            clearBoard();
            updateText(currPlayer+" goes first!");
        }
        else{
            updateText("Thanks for playing");
            JOptionPane.showMessageDialog(null, "Thanks for playing!");
            System.exit(EXIT_ON_CLOSE);
        }
        System.out.println(yesNo);
    }

    public void nextDrop(int col){
        for(int row = 5 ; row >=0; row--){
            if((!(board[row][col].getBackground().equals(Color.GREEN)) && !(board[row][col].getBackground().equals(Color.RED)) )){
                Color myColor = Color.GREEN;
                if(currPlayer.equals(playerTwo)){
                    myColor = Color.RED;
                }
                board[row][col].setBackground(myColor);

                if (row==0){
                    label[col].setEnabled(false);
                }
                break;
            }
        }


    }


    public void updateCurrPlayer() {
        if(currPlayer.equalsIgnoreCase(playerOne)){
            currPlayer = playerTwo;
        }
        else{
            currPlayer = playerOne;
        }

    }

    public boolean isWinner(String player) {

        Color myColor;
        if(currPlayer.equals(playerTwo)){
            myColor = Color.RED;}
        else {
            myColor = Color.GREEN;}


        //check rows
        for(int row=0; row<board.length; row++){
            int rowCount=0;//row match counter, resets on next row
            for(int col=0; col<board[row].length; col++){
                if(board[row][col].getBackground().equals(myColor)){

                    rowCount++;//increment counter
                } else {
                    rowCount=0;
                }
                if(rowCount == 4){
                    return true;//found 3 in same row

                }
            }
        }
        //check columns
        for(int col=0; col<7; col++){
            int colCount=0;
            for(int row=0; row<6; row++){
                if(board[row][col].getBackground().equals(myColor)){
                    colCount++;
                } else {colCount=0;	}
                if(colCount ==4){
                    return true;//found 3 in same column
                }
            }
        }



        //check main diagonal [0][0],[1][1],[2][2]

        int colInc=0;

        for(int i = 0; i < 4 ;i++){
            int col = colInc;
            int  row=0;


            int count=0;

            while (( col <= board.length) && (row < 6)){

                if(board[row][col].getBackground().equals(myColor)){
                    count++;
                } else {
                    count=0;
                }
                if (count == 4){
                    return true;}
                row++;
                col++; }
            colInc++; }


        //check main diagonal lower
        int rowInc=1;

        for(int i = 0; i < 2 ;i++){
            int col =0;
            int  row =rowInc;
            int count =0;


            while (( col <= board.length) && (row < 6)){
                if(board[row][col].getBackground().equals(myColor)){
                    count++;
                } else {
                    count=0;			}
                if (count == 4){
                    return true;

                }
                row++;
                col++;
            }

            System.out.println();

            rowInc++;

        }

        int colInc2 =0;
        for(int i =0; i < 4; i++){
            int rowCount = 5;
            int colCount = colInc2;
            int  countMatch=0;

            while ((colCount <= board.length)&& (rowCount >=0)){
                if(board[rowCount][colCount].getBackground().equals(myColor)){
                    countMatch++;
                } else {
                    countMatch=0;
                }
                if (countMatch == 4){
                    return true;

                }
                colCount++;
                rowCount--;
            }
            colInc2++;
        }

        int rowDec =4;

        for(int i =0; i < 2; i++){
            int rowCount = rowDec;// numrows -2
            int colCount = 0;
            int countMatch=0;

            while ((colCount <= board.length)&& (rowCount >=0)){
                if(board[rowCount][colCount].getBackground().equals(myColor)){
                    countMatch++;}
                else {rowCount=0;	}
                if (countMatch == 4){
                    return true;        	}

                colCount++;
                rowCount--;		}

            rowDec--;	}
        return false;
    }

    public boolean isFull() {
        for(int row=0; row<board.length; row++){
            for(int col=0; col<board[row].length; col++){
                if( !(board[row][col].getBackground().equals(Color.GREEN)) && !(board[row][col].getBackground().equals(Color.RED)) ){
                    return false;
                }

            }
        }
        return true;
    }
    public void clearBoard() {
        for(int row=0; row<board.length; row++) {
            for (int col = 0; col < board[row].length; col++) {
                board[row][col].setBackground(Color.BLUE);
            }
            for (int i = 0; i < label.length; i++) {
                label[i].setEnabled(true);

            }
        }
    }

    public void displayWinner() {


        if(currPlayer.equalsIgnoreCase(playerOne)){
            updateText(playerOne + " is the winner");
            p1count++;
            game.setTitle("Connect4 - Players (" + playerOne + " - "+p1count+" Wins, " + playerTwo + " - "+p2count+" Wins) Last Winner: " + playerOne);
        }
        else if (currPlayer.equalsIgnoreCase(playerTwo)){
            updateText(playerTwo + " is the winner");
            p2count++;
            game.setTitle("Connect4 - Players (" + playerOne + " - "+p1count+" Wins, " + playerTwo + " - "+p2count+" Wins) Last Winner: " + playerTwo);
        }
        else
        {
            updateText("DRAW");
        }

    }






}











